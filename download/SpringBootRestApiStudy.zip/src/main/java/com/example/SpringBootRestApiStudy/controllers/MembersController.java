package com.example.SpringBootRestApiStudy.controllers;

import com.example.SpringBootRestApiStudy.common.JwtAuth;
import com.example.SpringBootRestApiStudy.models.Member;
import com.example.SpringBootRestApiStudy.models.MembersResponse;
import com.example.SpringBootRestApiStudy.services.MembersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("api/v1/members")
public class MembersController {
    @Autowired
    private MembersService membersService;

    @RequestMapping(path = "", method = RequestMethod.POST)
    public MembersResponse membersCreate(@RequestBody Member member) {
        membersService.create(member);
        return new MembersResponse("created");
    }

    @RequestMapping(path = "", method = RequestMethod.GET)
    // public MembersResponse membersRead(@ModelAttribute Member member) {
    // public MembersResponse membersRead(@RequestParam("name") String title, @RequestParam(required=false, defaultValue="1") int age) {
    public MembersResponse membersRead() {
        List<Member> members = membersService.read();
        return new MembersResponse("read", members);
    }

    @RequestMapping(path = "/{memberPk}", method = RequestMethod.DELETE)
    public MembersResponse membersDelete(@PathVariable("memberPk") int memberPk) {
        membersService.delete(memberPk);
        return new MembersResponse("deleted");
    }

    @RequestMapping(path = "/{memberPk}", method = {RequestMethod.PUT, RequestMethod.PATCH})
    public MembersResponse membersUpdate(
            @PathVariable("memberPk") int memberPk,
            @RequestBody Member member
    ) {
        membersService.update(memberPk, member);
        return new MembersResponse("updated");
    }

    @RequestMapping(path = "/login", method = RequestMethod.POST)
    public String membersLogin(@RequestBody Member member) {
        Map<String, Object> mapMember = new HashMap<>();
        mapMember.put("name", member.getName());
        mapMember.put("age", member.getAge());
        return JwtAuth.tokenCreate(mapMember);
    }

    @RequestMapping(path = "/check", method = RequestMethod.GET)
    public Map<String, Object> membersCheck(
            @ApiIgnore @RequestAttribute Map<String, Object> member
    ) {
        return member;
    }
}
