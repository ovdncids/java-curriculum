package com.example.SpringBootRestApiStudy.controllers;

import com.example.SpringBootRestApiStudy.common.JwtAuth;
import com.example.SpringBootRestApiStudy.models.User;
import com.example.SpringBootRestApiStudy.models.UsersResponse;
import com.example.SpringBootRestApiStudy.services.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("api/v1/users")
public class UsersController {
    @Autowired
    private UsersService usersService;

    @RequestMapping(path = "", method = RequestMethod.POST)
    public UsersResponse usersCreate(@RequestBody User user) {
        usersService.create(user);
        return new UsersResponse("created");
    }

    @RequestMapping(path = "", method = RequestMethod.GET)
    // public UsersResponse usersRead(@ModelAttribute User user) {
    // public UsersResponse usersRead(@RequestParam("name") String title, @RequestParam(required=false, defaultValue="1") int age) {
    public UsersResponse usersRead() {
        List<User> users = usersService.read();
        return new UsersResponse("read", users);
    }

    @RequestMapping(path = "/{userPk}", method = RequestMethod.DELETE)
    public UsersResponse usersDelete(@PathVariable("userPk") int userPk) {
        usersService.delete(userPk);
        return new UsersResponse("deleted");
    }

    @RequestMapping(path = "/{userPk}", method = {RequestMethod.PUT, RequestMethod.PATCH})
    public UsersResponse usersUpdate(
            @PathVariable("userPk") int userPk,
            @RequestBody User user
    ) {
        usersService.update(userPk, user);
        return new UsersResponse("updated");
    }

    @RequestMapping(path = "/login", method = RequestMethod.POST)
    public String usersLogin(@RequestBody User user) {
        Map<String, Object> mapUser = new HashMap<>();
        mapUser.put("name", user.getName());
        mapUser.put("age", user.getAge());
        return JwtAuth.tokenCreate(mapUser);
    }

    @RequestMapping(path = "/check", method = RequestMethod.GET)
    public Map<String, Object> usersCheck(
            @ApiIgnore @RequestAttribute Map<String, Object> user
    ) {
        return user;
    }
}
