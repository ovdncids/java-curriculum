package com.example.SpringBootRestApiStudy.repositories;

import com.example.SpringBootRestApiStudy.models.Member;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MembersRepository {
    // @Select("select * from members")
    List<Member> read();

    Integer create(Member member);

    Integer delete(Integer memberPk);

    Integer update(@Param("memberPk") Integer memberPk, @Param("member") Member member);
}
