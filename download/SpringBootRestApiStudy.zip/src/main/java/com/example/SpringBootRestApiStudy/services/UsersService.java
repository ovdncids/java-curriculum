package com.example.SpringBootRestApiStudy.services;

import com.example.SpringBootRestApiStudy.models.User;
import com.example.SpringBootRestApiStudy.repositories.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersService {
    @Autowired
    private UsersRepository usersRepository;

    public List<User> read() {
        return usersRepository.read();
    }

    public Integer create(User user) {
        return usersRepository.create(user);
    }

    public Integer delete(Integer userPk) {
        return usersRepository.delete(userPk);
    }

    public Integer update(Integer userPk, User user) {
        return usersRepository.update(userPk, user);
    }
}
