package com.example.SpringBootRestApiStudy.models;

import java.util.List;

public class UsersResponse {
    public String result;
    public List<User> users;

    public UsersResponse() {}

    public UsersResponse(String result) {
        this.result = result;
    }

    public UsersResponse(String result, List<User> users) {
        this.result = result;
        this.users = users;
    }
}
