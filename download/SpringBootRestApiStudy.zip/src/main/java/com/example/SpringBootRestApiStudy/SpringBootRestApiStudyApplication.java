package com.example.SpringBootRestApiStudy;

import com.google.common.base.Predicates;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Collections;

@SpringBootApplication
public class SpringBootRestApiStudyApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApiStudyApplication.class, args);
	}

	@Configuration
	@EnableSwagger2
	public class SwaggerConfig {
		@Bean
		public Docket api() {
			return new Docket(DocumentationType.SWAGGER_2)
					.select()
					.apis(RequestHandlerSelectors.any())
					.paths(PathSelectors.any())
					.build();
		}

		@Bean
		public Docket apiJwt() {
			ApiKey apikey = new ApiKey("x-jwt-token", "x-jwt-token", "header");
			AuthorizationScope[] authorizationScopes = {};
			SecurityReference securityReference = new SecurityReference("x-jwt-token", authorizationScopes);
			SecurityContext securityContext = SecurityContext.builder().securityReferences(Collections.singletonList(securityReference)).build();

			return new Docket(DocumentationType.SWAGGER_2)
					// 그룹을 생성해서 Swagger 페이지 우측 상단에서 이동 가능
					.groupName("jwt-token")
					// Header에 x-jwt-token 받기
					.securitySchemes(Collections.singletonList(apikey))
					// API가 Header에서 받은 x-jwt-token 읽기
					.securityContexts(Collections.singletonList(securityContext))
					.select()
					.apis(RequestHandlerSelectors.basePackage("com.example.SpringBootRestApiStudy"))
					.paths(Predicates.or(PathSelectors.ant("/api/v1/members/login"), PathSelectors.ant("/api/v1/members/check")))
					.build();
		}
	}
}
