package com.example.SpringBootRestApiStudy.models;

import java.util.ArrayList;

public class MembersResponse {
    public String result;
    public ArrayList<Member> members;

    public MembersResponse(String result) {
        this.result = result;
    }

    public MembersResponse(String result, ArrayList<Member> members) {
        this.result = result;
        this.members = members;
    }
}
