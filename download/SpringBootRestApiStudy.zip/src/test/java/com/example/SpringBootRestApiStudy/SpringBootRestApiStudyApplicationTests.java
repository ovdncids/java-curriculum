package com.example.SpringBootRestApiStudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestApiStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
