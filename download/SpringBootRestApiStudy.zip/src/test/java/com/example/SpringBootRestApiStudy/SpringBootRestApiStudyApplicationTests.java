package com.example.SpringBootRestApiStudy;

import com.example.SpringBootRestApiStudy.models.Member;
import com.example.SpringBootRestApiStudy.services.MembersService;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class SpringBootRestApiStudyApplicationTests {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SqlSessionFactory sqlSessionFactory;

	@Autowired
	private MembersService membersService;

	@Test
	void contextLoads() {
	}

	@Test
	void membersRead() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<Member> members = sqlSession.selectList("com.example.SpringBootRestApiStudy.repositories.MembersRepository.read");
		logger.info("Done: MembersRepository.read");
	}

	@Test
	void membersCreate() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Integer count = sqlSession.insert(
				"com.example.SpringBootRestApiStudy.repositories.MembersRepository.create",
				new Member(0, "홍길동", 39)
		);
		logger.info("Done: MembersRepository.create");
	}

	@Test
	void membersDelete() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Integer count = sqlSession.delete(
				"com.example.SpringBootRestApiStudy.repositories.MembersRepository.delete",
				1
		);
		logger.info("Done: MembersRepository.delete");
	}

	@Test
	void membersUpdate() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Integer count = sqlSession.update(
				"com.example.SpringBootRestApiStudy.repositories.MembersRepository.update",
				new Member(2, "이순신", 33)
		);
		logger.info("Done: MembersRepository.update");
	}

	@Test
	void members() {
		List<Member> members = membersService.read();
		membersService.create(new Member(null, "semin", 20));
		membersService.delete(0);
		membersService.update(0, new Member(null, "min", 30));
	}
}
