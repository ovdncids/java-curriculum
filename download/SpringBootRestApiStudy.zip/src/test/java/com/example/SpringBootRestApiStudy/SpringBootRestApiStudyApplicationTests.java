package com.example.SpringBootRestApiStudy;

import com.example.SpringBootRestApiStudy.common.JwtAuth;
import com.example.SpringBootRestApiStudy.models.User;
import com.example.SpringBootRestApiStudy.services.UsersService;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootTest
class SpringBootRestApiStudyApplicationTests {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SqlSessionFactory sqlSessionFactory;

	@Autowired
	private UsersService usersService;

	@Test
	void contextLoads() {
	}

	@Test
	void usersRead() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<User> users = sqlSession.selectList("com.example.SpringBootRestApiStudy.repositories.UsersRepository.read");
		logger.info("Done: UsersRepository.read");
	}

	@Test
	void usersCreate() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Integer count = sqlSession.insert(
				"com.example.SpringBootRestApiStudy.repositories.UsersRepository.create",
				new User(0, "홍길동", 39)
		);
		logger.info("Done: UsersRepository.create");
	}

	@Test
	void usersDelete() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Integer count = sqlSession.delete(
				"com.example.SpringBootRestApiStudy.repositories.UsersRepository.delete",
				1
		);
		logger.info("Done: UsersRepository.delete");
	}

	@Test
	void usersUpdate() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		Integer count = sqlSession.update(
				"com.example.SpringBootRestApiStudy.repositories.UsersRepository.update",
				new User(2, "이순신", 33)
		);
		logger.info("Done: MembersRepository.update");
	}

	@Test
	void users() {
		List<User> users = usersService.read();
		usersService.create(new User(null, "홍길동", 39));
		usersService.delete(0);
		usersService.update(0, new User(null, "이순신", 33));
	}

	@Test
	void tokenCreate() {
		Map<String, Object> user = new HashMap<>();
		user.put("name", "홍길동");
		user.put("age", 39);
		String token = JwtAuth.tokenCreate(user);
		System.out.println(token);
	}

	@Test
	void tokenCheck() {
		String token = "tokenCreate 함수에서 생성한 token";
		Map<String, Object> user = JwtAuth.tokenCheck(token);
		System.out.println(user);
	}
}
