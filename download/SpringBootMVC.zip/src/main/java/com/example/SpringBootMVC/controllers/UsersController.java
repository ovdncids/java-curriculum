package com.example.SpringBootMVC.controllers;

import com.example.SpringBootMVC.models.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UsersController {
    private static List<User> init() {
        List<User> users = new ArrayList<>();
        users.add(new User("홍길동", 39));
        users.add(new User("김삼순", 33));
        users.add(new User("홍명보", 44));
        users.add(new User("박지삼", 22));
        users.add(new User("권명순", 10));
        return users;
    }
    public static final List<User> users = init();

    @RequestMapping(value = "/usersRead", method = RequestMethod.GET)
    ModelAndView usersRead() {
        ModelAndView modelAndView = new ModelAndView("users");
        modelAndView.addObject("result", "read");
        modelAndView.addObject("users", users);
        return modelAndView;
    }

    @RequestMapping(value = "/usersCreate", method = RequestMethod.POST)
    @ResponseBody
    String usersCreate(User user) {
        users.add(user);
        return "<script>document.location.href = '/usersRead';</script>";
    }

    @RequestMapping(value = "/usersDelete/{index}", method = RequestMethod.POST)
    @ResponseBody
    String usersDelete(@PathVariable("index") int index) {
        users.remove(index);
        return "<script>document.location.href = '/usersRead';</script>";
    }

    @RequestMapping(value = "/usersUpdate/{index}", method = RequestMethod.POST)
    @ResponseBody
    String usersUpdate(
            @PathVariable("index") int index,
            User user
    ) {
        users.set(index, user);
        return "<script>document.location.href = '/usersRead';</script>";
    }
}
